// Define what props.theme will look like
const main = {
    color: "",
    backgroundColor:"",
    primary: ""
  };

  const inverted = {
    color: "",
    backgroundColor:"",
    primary: ""
  }
  

  export { theme, inverted }